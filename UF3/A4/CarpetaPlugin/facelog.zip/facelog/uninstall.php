<?php // exit if uninstall constant is not defined
if (!defined('WP_UNINSTALL_PLUGIN')) exit;

// remove plugin options

// remove plugin transients

// remove plugin cron events

// ..etc., based on what needs to be removed



// Més info: https://digwp.com/2019/11/wordpress-uninstall-php/